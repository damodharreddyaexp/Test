package com.example.SampleSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SampleSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
