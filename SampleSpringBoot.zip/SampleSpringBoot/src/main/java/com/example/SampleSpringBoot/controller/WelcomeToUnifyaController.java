package com.example.SampleSpringBoot.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.SampleSpringBoot.service.impl.WelcomeToUnifyaServiceImpl;
import com.example.SampleSpringBoot.vo.TestResponse;
import com.example.SampleSpringBoot.vo.TestVo;

@RestController
public class WelcomeToUnifyaController {

	@Autowired
	WelcomeToUnifyaServiceImpl welcomeToUnifyaServiceImpl;

	@PostMapping
	public TestResponse createWorld(@RequestBody TestVo vo) {

		TestResponse response = welcomeToUnifyaServiceImpl.helloWorld(vo);

		return response;
		// HttpResponse<"Weclome">

	}

	@GetMapping
	public TestResponse retriveData(@PathVariable String name) {

		TestResponse isRetrieved = welcomeToUnifyaServiceImpl.retriveData(name);

		return isRetrieved;
		// HttpResponse<"Weclome">
		// HttpEntity<isRetrieved,>

	}

	@DeleteMapping
	public boolean deleteData(@PathVariable String name) {

		boolean isDeleted = welcomeToUnifyaServiceImpl.deleteData(name);

		return isDeleted;
		// HttpResponse<"Weclome">

	}

	@PutMapping
	public TestResponse updateData(@RequestBody TestVo vo) {

		TestResponse response = welcomeToUnifyaServiceImpl.updateData(vo);

		return response;
		// HttpResponse<"Weclome">

	}

}
