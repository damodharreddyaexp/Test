package com.example.SampleSpringBoot.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ObjectUtils;

import com.example.SampleSpringBoot.service.WelcomeToUnifyaService;
import com.example.SampleSpringBoot.vo.TestResponse;
import com.example.SampleSpringBoot.vo.TestVo;

@Service
public class WelcomeToUnifyaServiceImpl implements WelcomeToUnifyaService {

	@Override
	public TestResponse helloWorld(TestVo vo) {
		List<TestVo> list = null;
		list = createOrUpdate(vo, list);
		return extracted(list, "Created SuccesFully", "C");
	}

	public TestResponse retriveData(String name) {
		List<TestVo> list = new ArrayList<>();
		list.get(0);
		return extracted(list, "Retrieved Latest Record SuccesFully", "U");

	}

	public TestResponse updateData(TestVo vo) {
		List<TestVo> list = new ArrayList<>();
		list = createOrUpdate(vo, list);
		return extracted(list, "Updated Record SuccesFully", "U");

	}

	public boolean deleteData(String name) {

		return false;
	}

	private TestResponse extracted(List<TestVo> list, String s, String returnCode) {
		TestResponse response = null;
		if (!CollectionUtils.isEmpty(list)) {
			response = new TestResponse();
			response.setReturnCode(returnCode);
			response.setReturnMessage(s);
		}
		return response;
	}

	private List<TestVo> createOrUpdate(TestVo vo, List<TestVo> list) {
		if (!ObjectUtils.isEmpty(vo)) {
			list = new ArrayList<>();
			list.add(vo);
		}
		return list;
	}
}
