package com.example.SampleSpringBoot.service;

import org.springframework.stereotype.Component;

import com.example.SampleSpringBoot.vo.TestResponse;
import com.example.SampleSpringBoot.vo.TestVo;

@Component
public interface WelcomeToUnifyaService {

	public TestResponse helloWorld(TestVo vo);

	public TestResponse retriveData(String name);

}
